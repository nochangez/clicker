# coding: utf8

import os
from time import sleep

import pyautogui as pag

wrote = 0
while True:
	mouse_x, mouse_y = pag.position()
	x, y = pag.position()

	if x != mouse_x or y != mouse_y:
		os.system('clear')
		print(x, y)
	else:
		if wrote == 0:
			print(x, y)
			wrote += 1