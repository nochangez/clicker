# coding: utf-8

try:
	import os
	from time import sleep
	from subprocess import call

	import mouse
	import pyautogui as pag 
	import keyboard as kb 
except ImportError as err:
	# getting module:
	# cleaned = str(err).split("'")
	# missed_module = cleaned[1].strip("'")

	# print('missed module : %s' %missed_module)

	# if os.name == 'posix':	
	# 	print('installing...')

		# call(f"pip install {missed_module}", shell=True)
		# print('\n\n')
        print(f'[ERROR] {err}')

def docs():
	'''\
	Advice: 
	for low-powered pc's recommended delay is 0.01
	'''


class Clicker:
	def __init__(self, set_list):
		self.start_key = set_list[0]
		self.finish_key = set_list[1]
		self.exit_key = set_list[2]
		self.delay = set_list[3]

	def process(self):
		while True:
			if kb.is_pressed(self.start_key):
				while True:
					sleep(float(self.delay))
					mouse.double_click(button='left')

					if kb.is_pressed(self.finish_key):
						break
			elif kb.is_pressed(self.exit_key):
				break


if __name__ == '__main__':
	try:
		print(docs.__doc__)

		start_key = input('Start key: ')
		finish_key = input('Finish key: ')
		finish_program_key = input('Program finish key: ')
		delay = input('Delay between cycles: ')

		clicker = Clicker([start_key, finish_key, finish_program_key, delay])
		clicker.process()
	except KeyboardInterrupt:
		print('\nbye!')

		from time import sleep
		sleep(0.5)
		
		exit()
	except Exception as err:
		# pag.alert(err)
		print(f'[ERROR] {err}')